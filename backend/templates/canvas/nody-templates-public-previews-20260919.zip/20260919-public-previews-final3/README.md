# Public Template Download Report

- API: http://127.0.0.1:57396/api/templates/gallery?page_size=100
- Templates listed: 16
- Template details saved: 16
- Preview JSON files: 16
- Canvas nodes in previews: 264
- Canvas edges in previews: 359
- Referenced resource URLs recorded: 417
- Covers/demo media downloaded: 0 (URLs are preserved in the preview JSON and summary)
- Download errors: 0

## Access boundary

The public gallery, detail JSON and all 16 public preview JSON files were downloaded and validated.
The preview JSON contains the canvas graph, prompts, node configuration and referenced media URLs.
The API endpoint `/api/templates/{id}/download` returned HTTP 403 without an authenticated purchase and was not bypassed.
Paid templates therefore contain their public preview graph and resource references, not the protected full download package.

## Template list

- 爆款感电商详情页示例 | 020de02a-0e59-4461-b13d-320962481cb5 | price=0 | nodes=8 | edges=19 | tags=电商,详情页
- 酷炫动效提示词模板，适用于人/宠物 | 0dc2d28b-0614-4b7e-8503-f9e8993d1f2b | price=0 | nodes=3 | edges=2 | tags=电影
- 门店设计 | 1d4be0a1-b130-451d-a3be-97d43d8e18b5 | price=0 | nodes=7 | edges=6 | tags=设计
- 抖音产品广告 | 1e43b8d6-f7eb-46cf-ab9f-fe8349295912 | price=0 | nodes=9 | edges=12 | tags=广告,抖音产品广告
- 全能作图提示词补全 | 23e4701e-b2db-49e2-ae1e-4b8f1cfe79ee | price=0 | nodes=4 | edges=3 | tags=设计
- 杂志感电商详情页示例 | 35de3074-3277-4c64-8561-0b6aa8ba3715 | price=0 | nodes=8 | edges=16 | tags=电商,详情页
- 真人剧场版 | 45b54b8b-3909-4929-9329-d0fe200f1441 | price=500000 | nodes=9 | edges=6 | tags=其他,火影,剧场
- 电商口播 | 5f10f75f-cd16-490d-94e3-57f049d40e94 | price=0 | nodes=16 | edges=17 | tags=电商
- 人物一致性和seedance故事板 | 70edfc54-2804-4f03-815f-1f3bfbd97ce3 | price=0 | nodes=29 | edges=24 | tags=短剧
- TIKTOK产品宣传视频 | 867740ec-e0e1-4401-a520-72c69db9d678 | price=500000 | nodes=3 | edges=2 | tags=电商
- 亚马逊一键生成主副图和A+套图 | 8ffaeae2-0435-438f-997e-d9a214d7bc0a | price=500000 | nodes=26 | edges=54 | tags=电商,亚马逊,电商主图,电商详情页,A+
- 真人感照片 | b691c110-2b8a-4f77-8f5f-993a3395ab51 | price=500000 | nodes=18 | edges=12 | tags=设计,写真,自拍,写实
- 新闻报道 | ba3e658c-a4c0-48d2-99ed-2d4b9d4c8f76 | price=500000 | nodes=6 | edges=3 | tags=其他,新闻
- 长短剧模版，可更改集数，时间，可达网上百分之95的效果 | bf405d46-7982-4688-8ff8-27c8732ecda0 | price=0 | nodes=19 | edges=58 | tags=短剧
- 30W+浏览量抖音爆款漫改剧工作流 | f4a06247-f624-49e2-83e8-abfe3241a97b | price=0 | nodes=93 | edges=122 | tags=短剧,漫改
- 角色板及分镜故事板seedance直出 | f8925492-e464-4df1-a018-1b636f70ea39 | price=0 | nodes=6 | edges=3 | tags=短剧
